#include <windows.h>
#include <math.h>
#define PI acos(-1.0)

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, INT nCmdShow){
    int a = 10;
    for(;;){
        HDC hdc = GetDC(0);
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        POINT pos[3];
        pos[0].x = w - (cos(a * (PI / 180)) * w - sin(a * (PI / 180)) * h), pos[0].y = h - (cos(a * (PI / 180)) * h + sin(a * (PI / 180)) * w);
        pos[1].x = w + (sin(a * (PI / 180)) * h), pos[1].y = h - (cos(a * (PI / 180)) * h);
        pos[2].x = w - (cos(a * (PI / 180)) * w), pos[2].y = h - (sin(a * (PI / 180)) * w);
        PlgBlt(hdc, pos, hdc, 0, 0, w, h, 0, 0, 0);
        ReleaseDC(0,hdc);
        DeleteObject(hdc);
        Sleep(100);
    }
    return 0;
}